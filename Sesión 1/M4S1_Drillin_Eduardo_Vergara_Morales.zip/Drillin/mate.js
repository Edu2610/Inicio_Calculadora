let radio =5

console.log(`El  área del círculo es igual a: ${radio**2 * Math.PI}`)